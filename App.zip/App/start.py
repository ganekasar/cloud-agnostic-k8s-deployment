from kubernetes import client, config, watch
import appLib

def app_install(event):
    print(event)

def app_uninstall(event):
    print(event)

def app_mod(event):
    print(event)

# Configs can be set in Configuration class directly or using helper utility
config.load_kube_config()

v1 = client.CoreV1Api()
count = 10
w = watch.Watch()
for event in w.stream(v1.list_namespace, _request_timeout=60):
    print("Event: %s %s" % (event['type'], event['object'].metadata.name))
    if event['type']=='ADDED':
        app_install(event)
    elif event['type']=='DELETED':
        app_uninstall(event)
    else:
        app_mod(event)
    count -= 1
    if not count:
        w.stop()

print("Ended.")