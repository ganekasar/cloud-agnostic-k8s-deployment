import kopf
import kubernetes

class kubemanage:
    def create_app_deployment():
        print("A")
    def delete_app_ddeployment():
        print("D")
    def mod_app_deployment():
        print("M")